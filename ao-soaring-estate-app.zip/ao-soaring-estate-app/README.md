# A.O SOARING ESTATE app (customer APK)
1. Upload everything in this folder to a new GitHub repository (include the hidden .github folder).
2. Open the Actions tab, wait for the green tick, then download the APK from "Artifacts".
You build the APK only once. Updates made on your admin page show in the app by themselves.
